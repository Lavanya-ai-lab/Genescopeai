"""Reports computed exclusively from saved real experiment artifacts."""

import argparse
import json
import statistics
from collections import Counter
from pathlib import Path

from src.evaluation.dataset import load_cases


def build_report(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "experiment.json").read_text())
    cases = {c["id"]: c for c in load_cases()}
    records = [json.loads((directory / f"{id}.json").read_text())
               for id in cases if (directory / f"{id}.json").exists()]
    metrics = {}
    for name in ("grounded_correctness", "citation_validity", "uncertainty_handling", "workflow_completion"):
        counts = Counter(r["metrics"][name]["status"] for r in records)
        graded = counts["pass"] + counts["fail"]
        metrics[name] = {"pass": counts["pass"], "fail": counts["fail"],
                         "ungraded": counts["ungraded"], "not_applicable": counts["not_applicable"],
                         "graded": graded, "pass_fraction": counts["pass"] / graded if graded else None}
    failures = {}
    for record in records:
        case_id = record["case_id"]
        labels = set(record["metrics"]["workflow_completion"].get("failures", []))
        for name, score in record["metrics"].items():
            if score["status"] == "fail":
                labels.add(score.get("failure_type", name))
        for label in labels:
            failures.setdefault(label, []).append(case_id)
    ranked = sorted(({"failure": k, "case_count": len(v), "case_ids": v}
                     for k, v in failures.items()), key=lambda r: (-r["case_count"], r["failure"]))
    seconds = sorted(r["active_seconds"] for r in records)
    # Nearest-rank p95, explicitly not a service-level guarantee.
    import math
    latency = {"count": len(seconds), "median_seconds": statistics.median(seconds) if seconds else None,
               "p95_seconds": seconds[math.ceil(.95 * len(seconds)) - 1] if seconds else None,
               "total_active_seconds": sum(seconds), "definition": "active wall time; excludes human wait and evaluator calls"}
    return {"metadata": metadata, "completed": len(records), "expected": 40,
            "missing_case_ids": sorted(set(cases) - {r["case_id"] for r in records}),
            "metrics": metrics, "latency": latency,
            "top_failures": ranked[:3], "all_failures": ranked,
            "lanes": {lane: [r["case_id"] for r in records
                               if bool(cases[r["case_id"]].get("fixture")) == injected]
                      for lane, injected in (("normal", False), ("injected_fault", True))},
            "cases": [{"id": r["case_id"], "category": cases[r["case_id"]]["category"],
                       "fixture": r.get("fixture"), "metrics": r["metrics"],
                       "active_seconds": r["active_seconds"], "awaiting_review": r["awaiting_review"],
                       "trace_ids": r["trace_ids"]} for r in records]}


def compare(before, after):
    """Fail closed for mismatched inputs/settings and missing cases."""
    for key in ("dataset_sha256", "corpus_sha256", "evaluator_version", "judge_prompt_sha256",
                "application_model", "embedding_model", "judge_model", "packages", "concurrency", "repetitions"):
        if before["metadata"].get(key) != after["metadata"].get(key):
            raise ValueError(f"Experiments are not comparable: {key}")
    b = {r["id"]: r for r in before["cases"]}
    a = {r["id"]: r for r in after["cases"]}
    if set(b) != set(a) or len(a) != 40:
        raise ValueError("Comparison requires the identical complete 40 cases.")
    paired = []
    for id in b:
        changes = {}
        for name in before["metrics"]:
            old, new = b[id]["metrics"][name]["status"], a[id]["metrics"][name]["status"]
            changes[name] = {"before": old, "after": new,
                             "regression": old == "pass" and new == "fail",
                             "improvement": old == "fail" and new == "pass"}
        paired.append({"id": id, "metrics": changes,
                       "latency_delta_seconds": a[id]["active_seconds"] - b[id]["active_seconds"]})
    return {"before": before["metadata"], "after": after["metadata"], "paired_cases": paired}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--compare", type=Path)
    args = parser.parse_args()
    result = build_report(args.directory)
    if args.compare:
        result = compare(result, build_report(args.compare))
    print(json.dumps(result, ensure_ascii=False, indent=2))
