"""Opt-in LangSmith instrumentation; never change research decisions.

LangGraph supplies node/embedding traces. wrap_openai adds the existing raw
Nebius calls. A review resume is a new trace with the same thread metadata,
not a span held open while a researcher is away.
"""

import os
from contextlib import contextmanager
from pathlib import Path

from dotenv import load_dotenv
from langsmith import tracing_context
from langsmith.wrappers import wrap_openai


def tracing_enabled():
    load_dotenv(Path(__file__).resolve().parents[1] / ".env")
    return bool(os.getenv("LANGSMITH_API_KEY")) and os.getenv(
        "LANGSMITH_TRACING", "false"
    ).lower() == "true"


def graph_config(thread_id, phase="research", **metadata):
    return {
        "configurable": {"thread_id": thread_id},
        "metadata": {**metadata, "thread_id": thread_id,
                     "session_id": thread_id, "phase": phase},
        "tags": ["genescope", phase],
    }


@contextmanager
def research_trace():
    # Disable explicitly when no key is available, even if a shell has enabled
    # tracing. The SDK handles upload failures without changing graph output.
    with tracing_context(enabled=tracing_enabled()):
        yield


def trace_client(client):
    return wrap_openai(client) if tracing_enabled() else client
